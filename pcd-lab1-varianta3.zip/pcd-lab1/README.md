# Lucrare de laborator 1 - Crearea thread-urilor (Varianta 3)

**Student(i):** Nume Prenume, grupa XXX-000

## Sarcina
Doua fire de executie (create prin `Runnable`) citesc acelasi tablou `mas[100]` (valori 1..100, generat aleatoriu):

- **Th1 (Conditia 1):** sumele numerelor impare doua cate doua, cautarea incepe de la primul element.
- **Th2 (Conditia 2):** sumele numerelor impare doua cate doua, cautarea incepe de la ultimul element.

Dupa terminarea ambelor fire, thread-ul principal afiseaza informatia despre studenti, litera cu litera, la interval de 100 ms. Interfata grafica este realizata cu Swing.

## Rulare
```
javac Main.java
java Main
```
